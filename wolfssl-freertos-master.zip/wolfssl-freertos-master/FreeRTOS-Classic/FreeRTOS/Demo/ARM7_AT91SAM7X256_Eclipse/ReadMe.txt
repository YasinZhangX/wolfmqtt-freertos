If you need the demo that used to be in this directory then download FreeRTOS V8.2.3
from http://sourceforge.net/projects/freertos/files/FreeRTOS/

